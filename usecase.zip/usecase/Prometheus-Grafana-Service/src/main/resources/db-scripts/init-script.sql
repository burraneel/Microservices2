insert into PERSON (PERSON_ID,FIRST_NAME,LAST_NAME,EMAIL) values 
(1, 'Satish','Sharma','myid@company.com'),
(2, 'Gaurav','Gupta','myid@company.com'),
(3, 'Ashutosh','Chandrawat','myid@company.com')
;