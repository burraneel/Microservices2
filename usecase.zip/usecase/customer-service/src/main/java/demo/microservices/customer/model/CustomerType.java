package demo.microservices.customer.model;

public enum CustomerType {

	INDIVIDUAL, COMPANY;
	
}
