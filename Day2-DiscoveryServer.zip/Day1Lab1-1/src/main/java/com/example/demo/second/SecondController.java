package com.example.demo.second;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.second.service.ISecondService;


@RestController
public class SecondController {
	@Autowired
	ISecondService secondService;
	@RequestMapping(path = "/test")
	public  String test( ) {
		System.out.println("Presentation");
		String test = secondService.test("Presentation");
		return test;
		
	}
}
