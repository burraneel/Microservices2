package com.example.demo.second.service;

public interface ISecondService {
	public String test(String test);
}
