package com.example.demo.second.dao;

public interface ISecondDao {
	public String test(String test);
}
