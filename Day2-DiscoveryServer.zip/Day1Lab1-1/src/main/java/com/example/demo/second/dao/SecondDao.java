package com.example.demo.second.dao;

import org.springframework.stereotype.Repository;

@Repository
public class SecondDao implements ISecondDao {

	@Override
	public String test(String test) {
		System.out.println("Dao");
		return test + " Dao " ;
	}

}
