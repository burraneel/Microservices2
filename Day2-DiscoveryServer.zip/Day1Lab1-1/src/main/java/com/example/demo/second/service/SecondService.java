package com.example.demo.second.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.second.dao.ISecondDao;

@Service
public class SecondService implements ISecondService {

	@Autowired
	ISecondDao secondDao;
	@Override
	public String test(String test) {
		System.out.println("Service");
		return secondDao.test(test +" "+ "Service");
	}

}
