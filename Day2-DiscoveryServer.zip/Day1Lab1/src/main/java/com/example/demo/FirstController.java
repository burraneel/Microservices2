package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.service.IFirstService;


@RestController
@RequestMapping(path = "/test")
public class FirstController {
	@Autowired
	IFirstService firstService;
	@Autowired
	RestTemplate restTemplate;
	@RequestMapping(path = "/test")
	public  String test( ) {
		System.out.println("Presentation");
		String test = firstService.test("Presentation");
		 final String uri = "http://localhost:6060/second/test";
	     
		    String result = restTemplate.getForObject(uri, String.class);
		    System.out.println(result);
		return test;
		
	}
}
