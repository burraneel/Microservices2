package com.example.demo.dao;

public interface IFirstDao {
	public String test(String test);
}
