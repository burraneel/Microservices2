package com.example.demo.dao;

import org.springframework.stereotype.Repository;

@Repository
public class FirstDao implements IFirstDao {

	@Override
	public String test(String test) {
		System.out.println("Dao");
		return test + " Dao " ;
	}

}
