package com.example.demo.service;

public interface IFirstService {
	public String test(String test);
}
