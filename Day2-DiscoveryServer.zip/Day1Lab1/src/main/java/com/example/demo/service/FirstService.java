package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.IFirstDao;

@Service
public class FirstService implements IFirstService {

	@Autowired
	IFirstDao firstDao;
	@Override
	public String test(String test) {
		System.out.println("Service");
		return firstDao.test(test +" "+ "Service");
	}

}
