package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class PaymentController {

	@Autowired
	RestTemplate restTemplate;
	@RequestMapping("/processPayment")
	public String processPayment() {
		String message = restTemplate.getForObject("http://shipment-service/shipment/processShipment", String.class);
		return message+"2";
	}
}
