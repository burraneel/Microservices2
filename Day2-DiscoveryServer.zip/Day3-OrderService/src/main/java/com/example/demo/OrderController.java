package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RefreshScope
public class OrderController {

	@Autowired
	RestTemplate restTemplate;
	@Value("${msg: Config Server not working Please check}")
	private String message;
	
	@RequestMapping("/processOrder")
	@HystrixCommand(fallbackMethod = "defaulyMsg")
	public String processOrder() throws Exception {
			String msg = restTemplate.getForObject("http://payment-service/payment/processPayment", String.class);
			return "Order Created..." +message+"... Order Processed";
		
	}
	
	public String defaulyMsg() {
		return "Payment Process will be done later";
	}
}
