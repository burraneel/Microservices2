package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day1ConfigClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day1ConfigClientApplication.class, args);
	}
}

